
	<div id="dropDownSelect1"></div>
	<script src="<?= base_url('asset/cssauth/'); ?>vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="<?= base_url('asset/cssauth/'); ?>vendor/animsition/js/animsition.min.js"></script>
	<script src="<?= base_url('asset/cssauth/'); ?>vendor/bootstrap/js/popper.js"></script>
	<script src="<?= base_url('asset/cssauth/'); ?>vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?= base_url('asset/cssauth/'); ?>vendor/select2/select2.min.js"></script>
	<script src="<?= base_url('asset/cssauth/'); ?>vendor/daterangepicker/moment.min.js"></script>
	<script src="<?= base_url('asset/cssauth/'); ?>vendor/daterangepicker/daterangepicker.js"></script>
	<script src="<?= base_url('asset/cssauth/'); ?>vendor/countdowntime/countdowntime.js"></script>

	<script src="<?= base_url('asset/'); ?>js/main.js"></script>
</body>
</html>
