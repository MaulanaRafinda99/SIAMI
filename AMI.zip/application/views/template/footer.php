 <div class="footer">
                <div class="container">
                    <div class="col-md-3 footer-logo">
                        <a href="index.html"><img src="<?php echo base_url('asset/images/flogo.png')?>" title="brand-logo" /></a>
                    </div>
                    <div class="col-md-7 footer-links">
                        <ul class="unstyled-list list-inline">
                            <li><a href="#"> Terms and Conditions</a> <span> </span></li>
                            <li><a href="#"> Secure Payments</a> <span> </span></li>
                            <li><a href="#"> Shipping</a> <span> </span></li>
                            <li><a href="contact.html"> Contact</a> </li>
                            <div class="clearfix"> </div>
                        </ul>
                    </div>
                    <div class="col-md-2 footer-social">
                        <ul class="unstyled-list list-inline">
                            <li><a class="pin" href="#"><span> </span></a></li>
                            <li><a class="twitter" href="#"><span> </span></a></li>
                            <li><a class="facebook" href="#"><span> </span></a></li>
                            <div class="clearfix"> </div>
                        </ul>
                    </div>
                    <div class="clearfix"> </div>
                </div>
             </div>
             <div class="clearfix"> </div>
            <!---//footer--->
            <!---copy-right--->
                    <div class="copy-right">
                        <div class="container">
                            <p>Copyright @2019 - IlulJr</a></p>
                            <script type="text/javascript">
                                    $(document).ready(function() {
                                        /*
                                        var defaults = {
                                            containerID: 'toTop', // fading element id
                                            containerHoverID: 'toTopHover', // fading element hover id
                                            scrollSpeed: 1200,
                                            easingType: 'linear'
                                        };
                                        */

                                        $().UItoTop({ easingType: 'easeOutQuart' });

                                    });
                                </script>
                            <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
                        </div>
                    </div>
            <!--//copy-right--->
    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="<?php echo base_url('asset/'); ?>js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="<?php echo base_url('asset/'); ?>js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo base_url('asset/'); ?>js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="<?php echo base_url('asset/'); ?>js/plugins.js"></script>
    <!-- Active js -->
    <script src="<?php echo base_url('asset/'); ?>js/active.js"></script>
    <script src="<?= base_url('assets/'); ?>js/jsscript.js"></script>

</body>

</html>
