<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login Form</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="<?php echo base_url('asset/images/icons/favicon.ico')?>" rel="icon" type="image.png" />
  <link href="<?php echo base_url('asset/css/fonts/font-awesome-4.7.0/css/font-awesome.min.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url('asset/css/fonts/iconic/css/material-design-iconic-font.min.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url('asset/css/login/util.css')?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url('asset/css/login/main.css')?>" rel="stylesheet" type="text/css" />
</head>
<body>
