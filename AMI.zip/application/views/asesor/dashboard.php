<div class="container-fluid">

  <div class="mb-4">

    <!-- Illustrations -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Sistem Audit Mutu Internal UTU</h6>
      </div>
      <div class="card-body">
        <div class="text-center">
          <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 48rem;" src="<?= base_url(''); ?>assets/img/undraw_posting_photo.svg" alt="...">
        </div>
        <p></p>
      </div>
    </div>

  </div>
  <!-- /.container-fluid -->

</div>