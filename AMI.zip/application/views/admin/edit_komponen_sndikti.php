<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Audit Mutu Internal UTU</h6>
        </div>
        <div class="card-body">
            <?php
            foreach ($komponen_sndikti as $snd) {
            ?>

                <form method="post" action="<?php echo base_url('admin/update_komponen_sndikti'); ?>">
                    <div class="form-group">
                        <label>SNDIKTI</label>
                        <input type="hidden" name="id_sndikti" value="<?php echo $snd->id_sndikti; ?>">
                        <input type="text" name="sndikti" class="form-control" placeholder="SNDIKTI" value="<?php echo $snd->sndikti; ?>">
                        <br>
                        <label>IKU SNDIKTI</label>
                        <input type="text" name="iku_sndikti" class="form-control" placeholder="IKU SNDIKTI" value="<?php echo $snd->iku_sndikti; ?>">
                        <br>
                    </div>
                    <button type="reset" class="btn btn-denger" data-dismiss="modal">Reset</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>

            <?php } ?>
        </div>
    </div>
</div>