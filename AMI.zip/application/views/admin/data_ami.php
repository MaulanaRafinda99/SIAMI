<div class="container-fluid">

    <div class="mb-4">

        <!-- Illustrations -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Data AMI</h6>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo base_url('admin/data_ami'); ?>">
                    <table align="left" class="mb-3">
                        <tr>
                            <td align="right">Instansi:</td>
                            <td>

                                <select name="id_instansi" id="id_instansi" class="custom-select custom-select-sm">
                                    <?php
                                    foreach ($instansi as $in) :
                                    ?>
                                        <option value="<?= $in['id_instansi'] ?>" class="dropdown-item"><?= $in['nama_instansi'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>&nbsp;</td>
                            <td align="right">Siklus:</td>
                            <td>
                                <select name="id_siklus" id="id_siklus" class="custom-select custom-select-sm">
                                    <?php
                                    foreach ($siklus as $si) :
                                    ?>
                                        <option value="<?= $si['id_siklus'] ?>" class="dropdown-item"><?= $si['tahun'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>&nbsp;</td>
                            <td>
                                <button type="submit" class="btn btn-info  ">Pilih</button>
                            <td>&nbsp;</td>
                    </table>
                </form>


                <div class="table-responsive">
                    <table class="table table-bordered" width="1600px" cellspacing="0">
                        <thead align="center">
                            <tr>
                                <th>No</th>
                                <th>Siklus</th>
                                <th>Nama Instansi</th>
                                <th>SNDIKTI</th>
                                <th>IKU SNDIKTI</th>
                                <th>Link Dokumen</th>
                                <th>Bobot</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            foreach ($data_ami as $ami) :
                            ?>
                                <tr align="center">
                                    <td><?= $i++; ?></td>
                                    <input type="hidden" name="id[]" value="<?= $ami['id_transaksi'] ?>">
                                    <td><span class="badge badge-info">Siklus <?= $ami['kode_siklus'] ?></span></td>
                                    <td><?= $ami['nama_instansi'] ?></td>
                                    <td align="justify"><?= $ami['sndikti'] ?></td>
                                    <td align="justify"><?= $ami['iku_sndikti'] ?></td>
                                    <td><a href="<?= $ami['link'] ?>">Dokumen</a></td>
                                    <td><?= $ami['bobot'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>