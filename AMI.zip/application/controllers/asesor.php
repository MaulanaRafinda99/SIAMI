<?php
class asesor extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('level') != 3) {
            redirect('auth');
        }
        $this->load->model('model_log');
        $this->load->model('model_asesor');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $this->session->unset_userdata('id_siklus');
        $this->session->unset_userdata('id_instansi');
        if ($this->input->post('submit')) {
            $data['id_siklus'] = $this->input->post('id_siklus');
            $data['id_instansi'] = $this->input->post('id_instansi');
            $this->session->set_userdata('id_siklus', $data['id_siklus']);
            $this->session->set_userdata('id_prodi', $data['id_prodi']);
        } else {
            $data['id_siklus'] = $this->session->userdata('id_siklus');
            $data['id_instansi'] = $this->session->userdata('id_instansi');
        }
        $data['judul'] = 'Data Audit';

        $data['id_user'] = $this->session->userdata('id_user');


        $this->db->where('id_user', $data['id_user']);
        $query2 = $this->db->get('data_asesor');
        foreach ($query2->result() as $row) {
            $sar = array(
                'id_instansi' => $row->id_instansi,
            );
        }
        $this->session->set_userdata($sar);

        $this->db->where('sekarang', 1);
        $query3 = $this->db->get('siklus');
        foreach ($query3->result() as $row) {
            $sar1 = array(
                'id_siklus_sekarang' => $row->id_siklus,
                'tahun_sekarang' => $row->tahun,
                'kode_siklus' => $row->kode_siklus,
            );
        }

        $this->session->set_userdata($sar1);

        $this->load->view("asesor/layout/header_admin");
        $this->load->view("asesor/layout/sidebar", $data);
        $this->load->view("asesor/layout/topbar_admin");
        $this->load->view("asesor/dashboard", $data);
        $this->load->view("asesor/layout/footer_admin");
    }

    public function sndikti()
    {

        $data['judul'] = 'Data Audit';
        $data['id_user'] = $this->session->userdata('id_user');

        $data['id_siklus_sekarang'] = $this->session->userdata('id_siklus_sekarang');
        $data['kode_siklus'] = $this->session->userdata('kode_siklus');

        $data['id'] = $this->session->userdata('id_user');
        $data['ins'] = $this->session->userdata('id_instansi');
        $data['sndikti'] = $this->model_asesor->getsndikti2($data['ins'], $data['id_siklus_sekarang']);
        $data['instansi'] = $this->model_asesor->getinstansi($data['ins']);

        $this->load->view("asesor/layout/header_admin");
        $this->load->view("asesor/layout/sidebar", $data);
        $this->load->view("asesor/layout/topbar_admin");
        $this->load->view("asesor/sndikti", $data);
        $this->load->view("asesor/layout/footer_admin");
    }

    public function update_sndikti()
    {
        $data = $this->input->post();

        for ($i = 0; $i < count($data['id']); $i++) {
            $batch[] = array(
                'id_transaksi' => $data['id'][$i],
                'bobot' => $data['bobot'][$i],
            );
        }
        // $data1['id_akses'] = $this->session->userdata('username');

        // var_dump($data1['id_akses']);

        $this->db->update_batch('data_ami', $batch, 'id_transaksi');
        redirect('asesor/sndikti');
    }
}
